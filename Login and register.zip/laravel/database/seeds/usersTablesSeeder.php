<?php

use Illuminate\Database\Seeder;
use App\user;

class usersTablesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        user::create([
        	'name'          => 'longishu',
        	'email'         => 'longishu30@gmail.com',
        	'password'      =>hash::make ('password'),
        	'remember_token'=> str_random(10)
        ]);
    }
}
