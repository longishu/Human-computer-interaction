<?php

        $dbHost     = 'localhost';
        $dbUsername = 'root';
        $dbPassword = '';
        $dbName     = 'final';
  $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }
        







?>

<!DOCTYPE html>
<html>
  <title>print data</title>
</head>
<body>
    
    <?php
     $result = $db->query("SELECT * FROM images ");
      if ($result->num_rows > 0) {
        echo "<table border=2 width = 80%>";
                echo "<tr>";
                echo "<th>FoodItem</th>";
                echo "<th>Image</th>";
                echo "<th>price</th>";
       echo "</tr>";

        while($row = $result->fetch_assoc()) {
            $image=($row['image']);
            print "<tr> <td>";
            echo  $row["Fooditem"] ;
            print "</td> <td>";
            echo  '<img src="data:image/jpeg;base64,'.base64_encode($image).'" height="100" width="100" class="img-thumnail" />' ;
            print "</td> <td>";
            echo  $row["price"];
            print "</td> </tr>";
            
          }
        }

    ?>
  
  </table>

</body>
</html>