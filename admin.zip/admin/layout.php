<html>
    <head>
    	<title>
    		FOOD PLUS
    	</title>
    	<link rel="stylesheet" type="text/css" href="stylz.css">
    </head>
    <body>
    	<header>
    		<div class="row">
    			<ul class="main-nav">

    				  <a href="uploadz.php"> UPDATE </a>
                      <a href="display.php"> VIEW ITEMS </a>
                      <a href="logindatabase.php">   LOGIN </a>
                      <a href="signup.php"> SIGNUP </a>
                       <a href="customerorder.php">ORDER </a>

    			</ul>
    			</div>
    	</header>
    </body>
    </html>

    