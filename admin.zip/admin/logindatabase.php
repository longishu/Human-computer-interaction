<?php
if(isset($_POST["signin"]))
  

  {
        $username= $_POST["username"];
        $password=$_POST["password"];

  
        $dbHost     = 'localhost';
        $dbUsername = 'root';
        $dbPassword = '';
        $dbName     = 'final';
        
        //Create connection and select DB
        $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }
        
        
        //Insert image content into database
        $insert = $db->query("INSERT into customlogin( username,password) VALUES ('$username','$password')");
        if($insert) {
            echo " logged in successfully.";
        }else{
            echo "login  failed, please try again.";
        } 
    }else{
        echo "Please fill in your cridentials.";
    }
    
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="loginform.css">

</head>
<body>
    <form action="logindatabase.php" method="post">
    <div class="login-box">
<h1>CUSTOMER LOGIN</h1>
   <div class="textbox">
    <i class="fa fa-user" aria-hidden="true"></i>
    <input type="text" placeholder="username" name="username" value="">

</div>
<div class="textbox">
    <i class="fa fa-key" aria-hidden="true"></i>
    <input type="text" placeholder ="password" name="password" value="">
</div>
<div>
<input  class="btn" type="submit" name="signin"  value="login">


</div>

</body>
</html>
