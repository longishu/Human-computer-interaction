<?php 
session_start();
$connect=mysql_connect("localhost","root","","final");

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<br/>
	<div class="container" style="width:700px; ">
		 <h3 align="center"> shopping cart</h3><br/>
		 <?php 
		 $query= "SELECT * FROM images";

		 ?>
		 <div class="cool" >
		 	
		 </div>
	</div>

</body>
</html>