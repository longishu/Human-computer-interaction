
<?php
if(isset($_POST["submit"]))
  

  {
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false)
    {
        $image = $_FILES['image']['tmp_name'];
        $imgContent = addslashes(file_get_contents($image));

        $item= $_POST["item"];

        $price=$_POST["price"];

  
        $dbHost     = 'localhost';
        $dbUsername = 'root';
        $dbPassword = '';
        $dbName     = 'final';
        
        //Create connection and select DB
        $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
        
        // Check connection
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }
        
        
        //Insert image content into database
        $insert = $db->query("INSERT into images ( Fooditem,price,image) VALUES ('$item','$price','$imgContent')");
        if($insert) {
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    }else{
        echo "Please select an image file to upload.";
    }
    }
?>

<!DOCTYPE html>
<html>
	<head>
	<style>
		div{
			margin: 20px 20px;
		}
		   input[type=text]
		{
			margin-left:30px;
		}
    </div>

	</style>
	 <link rel="stylesheet" type="text/css" href="uploadz.css">
	</head>
	<body>
	 <form action="uploadz.php" method="post" enctype="multipart/form-data">
	 	<div class="textzone">
			<label>Food Item: </label><input type="text" name="item" style="">
		</div>
		<div class="textzone">
        <label>Select image to upload:</label><input type="file" name="image"/>
        <div>
        <div class="textzone">
			<label>Price: </label><input type="text" name="price">
		</div>
        <input type="submit" name="submit" value="UPLOAD"/>
    </form>
	</body>
</html>